As of 2002-11-13 WordNet Lucene contribution contains a single Java class:
	org.apache.lucene.wordnet.Syns2Index.

This class creates a Lucene index with synonyms for English words from
a Prolog file, which is a part of WordNet database.
