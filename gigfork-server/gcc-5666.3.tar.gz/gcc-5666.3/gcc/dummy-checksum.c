const unsigned char executable_checksum[16] = { 0 };
