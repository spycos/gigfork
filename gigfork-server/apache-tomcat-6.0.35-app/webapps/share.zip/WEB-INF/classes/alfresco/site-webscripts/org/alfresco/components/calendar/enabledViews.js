// Enabled Calendar Views
// These settings are parsed both by the template level calendar.js and helper.js used by [toolbar|view].get.js calendar components (that means a server restart is needed to pick up changes).
model.defaultView= "month";
model.enabledViews= {day: true, week: true, month: true, agenda: true};