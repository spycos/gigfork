Alfresco Community 4.0
======================

For Enterprise subscribers, refer to http://support.alfresco.com for release notes and detailed information on this release.

For Community members, refer to the Alfresco wiki for more information on this release.


