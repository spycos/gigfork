Sharepoint Protocol Module
--------------------------

